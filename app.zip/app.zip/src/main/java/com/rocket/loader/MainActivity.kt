package com.rocket.loader

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    private lateinit var container: FrameLayout
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var button: Button
    private var web: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())

    private val stages = listOf("Root получен ✓", "Подготовка…", "Загрузка RocketCheat…", "Запуск…")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyImmersive()
        container = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#1a1208")) }
        setContentView(container)
        showLoader()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- экран загрузчика ----------
    private fun showLoader() {
        container.removeAllViews()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(16), dp(32), dp(16))
        }
        val title = TextView(this).apply {
            text = "RocketCheat"; textSize = 34f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#ff8800")); typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "Loader · StandRocket V1.07"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#ffaa44"))
        }
        status = TextView(this).apply {
            text = "Для запуска нужен root (KernelSU)"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#ff8844")); setPadding(0, dp(24), 0, dp(12))
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; visibility = View.INVISIBLE
        }
        button = Button(this).apply {
            text = "🔓 ПОЛУЧИТЬ ROOT"; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#cc6600"))
            setOnClickListener { requestRoot() }
        }
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(bar, LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(button, LinearLayout.LayoutParams(dp(280), dp(52)).apply { topMargin = dp(16) })
        container.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ---------- root через KernelSU (настоящий запрос su) ----------
    private fun requestRoot() {
        button.isEnabled = false
        status.text = "Запрашиваю root… подтверди в KernelSU"
        Thread {
            val ok = hasRoot()
            runOnUiThread { if (ok) runStages() else rootDenied() }
        }.start()
    }

    private fun hasRoot(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            if (!p.waitFor(30, TimeUnit.SECONDS)) { p.destroy(); return false }
            val out = p.inputStream.bufferedReader().readText()
            p.exitValue() == 0 && out.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    private fun rootDenied() {
        status.text = "Root не выдан.\nKernelSU → Суперпользователь → разреши RocketCheat и нажми снова"
        button.text = "🔁 ПОВТОРИТЬ"
        button.isEnabled = true
    }

    // ---------- красивая «загрузка» ----------
    private fun runStages() {
        bar.visibility = View.VISIBLE
        button.visibility = View.GONE
        var i = 0
        val step = object : Runnable {
            override fun run() {
                if (i >= stages.size) { startGame(); return }
                status.text = stages[i]
                bar.progress = (i + 1) * 100 / stages.size
                i++
                handler.postDelayed(this, 700)
            }
        }
        handler.post(step)
    }

    // ---------- игра (assets/index.html) ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun startGame() {
        val w = WebView(this)
        w.setBackgroundColor(Color.parseColor("#0a0c12"))
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }
        w.webViewClient = WebViewClient()
        w.webChromeClient = object : WebChromeClient() {
            // игра использует alert / confirm / prompt — без этого они молча не работают
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setNegativeButton("Отмена") { _, _ -> result?.cancel() }.show()
                return true
            }

            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult?): Boolean {
                val input = EditText(this@MainActivity).apply { setText(defaultValue ?: "") }
                AlertDialog.Builder(this@MainActivity).setMessage(message).setView(input).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("Отмена") { _, _ -> result?.cancel() }.show()
                return true
            }

            // загрузка фото (аватар, галочка, аватар клана)
            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(fileChooserParams!!.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
        container.removeAllViews()
        container.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web = w
        w.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web == null) { @Suppress("DEPRECATION") super.onBackPressed(); return }
        AlertDialog.Builder(this).setMessage("Выйти из игры?")
            .setPositiveButton("Да") { _, _ -> finish() }
            .setNegativeButton("Нет", null).show()
    }

    // ---------- полноэкранный режим ----------
    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        if (Build.VERSION.SDK_INT >= 28) {
            val a = window.attributes
            a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = a
        }
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    override fun onResume() { super.onResume(); web?.onResume() }
    override fun onPause() { web?.onPause(); super.onPause() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); web?.destroy(); super.onDestroy() }

    companion object { private const val REQ_FILE = 1001 }
}
