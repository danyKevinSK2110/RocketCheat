plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rocket.loader"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rocket.loader"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.07"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
